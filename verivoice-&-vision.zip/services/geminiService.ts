
import { GoogleGenAI, Type } from "@google/genai";
import { VoiceDetectionResult } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const detectVoiceGeneration = async (
  audioBase64: string,
  mimeType: string,
  targetLanguage: string
): Promise<VoiceDetectionResult> => {
  const ai = getAI();
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType,
            data: audioBase64
          }
        },
        {
          text: `Analyze this voice sample. 
          Languages: Tamil, English, Hindi, Malayalam, Telugu.
          Target: ${targetLanguage}.
          
          Determine if AI-generated or Human. 
          Provide granular scores (0 to 1) for:
          1. prosodyNaturalness: Rhythm/breathing flow.
          2. spectralConsistency: Cleanliness vs digital noise.
          3. artifactPresence: Neural glitches or robotic pops.
          4. emotionalNuance: Real human inflection vs monotone.

          Return JSON:
          {
            "classification": "AI" | "Human",
            "confidence": 0-1,
            "explanation": "string",
            "languageDetected": "string",
            "subScores": {
              "prosodyNaturalness": 0-1,
              "spectralConsistency": 0-1,
              "artifactPresence": 0-1,
              "emotionalNuance": 0-1
            }
          }`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          classification: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          explanation: { type: Type.STRING },
          languageDetected: { type: Type.STRING },
          subScores: {
            type: Type.OBJECT,
            properties: {
              prosodyNaturalness: { type: Type.NUMBER },
              spectralConsistency: { type: Type.NUMBER },
              artifactPresence: { type: Type.NUMBER },
              emotionalNuance: { type: Type.NUMBER }
            },
            required: ["prosodyNaturalness", "spectralConsistency", "artifactPresence", "emotionalNuance"]
          }
        },
        required: ["classification", "confidence", "explanation", "subScores"]
      }
    }
  });

  try {
    const result = JSON.parse(response.text || '{}');
    return result as VoiceDetectionResult;
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Invalid response from detection engine");
  }
};

export const editImageWithPrompt = async (
  imageBase64: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  const ai = getAI();
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType,
            data: imageBase64
          }
        },
        {
          text: `Edit this image based on the following instruction: "${prompt}".`
        }
      ]
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }

  throw new Error("No image returned.");
};
