
import React, { useState } from 'react';
import { AppState } from './types';
import VoiceDetector from './components/VoiceDetector';
import ImageEditor from './components/ImageEditor';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({ activeTab: 'voice' });

  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8">
      {/* Header */}
      <header className="w-full max-w-5xl flex flex-col md:flex-row justify-between items-center gap-4 mb-12">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <i className="fas fa-shield-halved text-2xl text-white"></i>
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Veri<span className="gradient-text">Voice</span> & Vision
            </h1>
            <p className="text-slate-400 text-sm">Next-Gen Audio & Image Authentication</p>
          </div>
        </div>

        <nav className="flex p-1 bg-slate-800/50 rounded-lg border border-slate-700/50">
          <button
            onClick={() => setState({ activeTab: 'voice' })}
            className={`px-6 py-2 rounded-md transition-all font-medium flex items-center gap-2 ${
              state.activeTab === 'voice' 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fas fa-waveform"></i>
            Voice Check
          </button>
          <button
            onClick={() => setState({ activeTab: 'image' })}
            className={`px-6 py-2 rounded-md transition-all font-medium flex items-center gap-2 ${
              state.activeTab === 'image' 
                ? 'bg-purple-600 text-white shadow-lg' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fas fa-wand-magic-sparkles"></i>
            Image Edit
          </button>
        </nav>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-5xl">
        {state.activeTab === 'voice' ? <VoiceDetector /> : <ImageEditor />}
      </main>

      {/* Footer */}
      <footer className="mt-auto pt-12 pb-6 text-slate-500 text-sm flex flex-col items-center gap-2">
        <div className="flex gap-4">
          <span className="hover:text-slate-300 transition-colors cursor-pointer">Security Protocol 3.0</span>
          <span className="hover:text-slate-300 transition-colors cursor-pointer">Gemini AI Enhanced</span>
        </div>
        <p>&copy; 2024 VeriVoice Technologies. All systems nominal.</p>
      </footer>
    </div>
  );
};

export default App;
