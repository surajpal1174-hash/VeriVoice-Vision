
import React, { useState, useRef } from 'react';
import { FileData } from '../types';
import { editImageWithPrompt } from '../services/geminiService';

const SUGGESTIONS = [
  "Add a retro 80s neon filter",
  "Remove the background",
  "Make it look like an oil painting",
  "Add a cinematic moody lighting",
  "Convert to high contrast black and white"
];

const ImageEditor: React.FC = () => {
  const [file, setFile] = useState<FileData | null>(null);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.type.startsWith('image/')) {
      setError("Please upload an image file (PNG/JPG)");
      return;
    }

    setError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      setFile({
        base64,
        mimeType: selectedFile.type,
        previewUrl: URL.createObjectURL(selectedFile),
        fileName: selectedFile.name
      });
      setResultImage(null);
    };
    reader.readAsDataURL(selectedFile);
  };

  const handleEdit = async () => {
    if (!file || !prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const edited = await editImageWithPrompt(file.base64, file.mimeType, prompt);
      setResultImage(edited);
    } catch (err: any) {
      setError(err.message || "Failed to process image.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!resultImage) return;
    const link = document.createElement('a');
    link.href = resultImage;
    link.download = `edited_${file?.fileName || 'image'}.png`;
    link.click();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fadeIn">
      {/* Studio Controls */}
      <div className="glass-card p-6 md:p-8 rounded-2xl flex flex-col h-fit">
        <h2 className="text-2xl font-semibold mb-2 flex items-center gap-2">
          <i className="fas fa-palette text-purple-500"></i>
          AI Vision Studio
        </h2>
        <p className="text-slate-400 mb-8">Prompt-driven image manipulation powered by Gemini 2.5 Flash.</p>

        <div className="mb-6">
          <label className="block text-sm text-slate-400 mb-2">Original Asset</label>
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`relative rounded-xl overflow-hidden cursor-pointer group h-64 bg-slate-900 border-2 border-dashed ${
              file ? 'border-purple-500' : 'border-slate-700 hover:border-slate-500'
            }`}
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange} 
            />
            {file ? (
              <>
                <img src={file.previewUrl} className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <i className="fas fa-sync text-2xl mb-2 text-white"></i>
                  <span className="text-xs font-bold uppercase tracking-tighter">Change Image</span>
                </div>
              </>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
                <i className="fas fa-image text-3xl text-slate-700"></i>
                <span className="text-sm font-medium text-slate-500">Upload Source Image</span>
              </div>
            )}
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm text-slate-400 mb-2 font-medium">Magic Instruction</label>
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., 'Add a retro 80s synthwave glow to the subject'..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-4 text-slate-200 placeholder-slate-600 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none min-h-[100px] transition-all"
            />
            <div className="absolute bottom-3 right-3">
              <i className="fas fa-keyboard text-slate-700"></i>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <p className="text-xs text-slate-500 mb-2 uppercase font-bold tracking-wider">Quick Presets</p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => setPrompt(s)}
                className="px-3 py-1.5 rounded-full bg-slate-800 border border-slate-700 text-slate-400 text-xs hover:bg-slate-700 hover:text-white transition-all"
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <button
          disabled={!file || !prompt.trim() || loading}
          onClick={handleEdit}
          className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
            !file || !prompt.trim() || loading 
              ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
              : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-500/20'
          }`}
        >
          {loading ? (
            <>
              <i className="fas fa-circle-notch fa-spin"></i>
              Dreaming...
            </>
          ) : (
            <>
              <i className="fas fa-wand-magic-sparkles"></i>
              Render Transformation
            </>
          )}
        </button>

        {error && (
          <div className="mt-4 p-4 bg-red-500/10 border border-red-500/50 rounded-lg flex items-center gap-3 text-red-400">
            <i className="fas fa-circle-exclamation"></i>
            <span className="text-sm">{error}</span>
          </div>
        )}
      </div>

      {/* Output Display */}
      <div className="flex flex-col gap-6">
        <div className="glass-card p-4 rounded-2xl flex-1 flex flex-col min-h-[500px]">
          <div className="flex justify-between items-center mb-4 px-2">
            <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500">Output Monitor</h3>
            {resultImage && (
               <button 
                onClick={handleDownload}
                className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors"
               >
                 <i className="fas fa-download"></i>
                 SAVE AS PNG
               </button>
            )}
          </div>

          <div className="flex-1 rounded-xl bg-slate-950/50 overflow-hidden relative border border-slate-800/50">
            {!resultImage && !loading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-700 text-center p-8">
                <i className="fas fa-sparkles text-5xl mb-4 opacity-10"></i>
                <p className="max-w-xs text-sm">Output will appear here once the neural renderer completes the request.</p>
              </div>
            )}

            {loading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-sm z-10">
                <div className="w-12 h-12 relative">
                   <div className="absolute inset-0 border-2 border-purple-500/20 rounded-full"></div>
                   <div className="absolute inset-0 border-t-2 border-purple-500 rounded-full animate-spin"></div>
                </div>
                <p className="mt-4 text-purple-400 text-xs font-mono uppercase tracking-[0.2em]">Processing Vision Buffer</p>
              </div>
            )}

            {resultImage && (
              <img 
                src={resultImage} 
                className="w-full h-full object-contain animate-fadeIn"
                alt="AI Generated"
              />
            )}
          </div>

          {resultImage && (
            <div className="mt-4 p-4 bg-purple-500/5 border border-purple-500/10 rounded-xl">
               <div className="flex items-center gap-2 text-xs font-medium text-purple-400 mb-1">
                 <i className="fas fa-info-circle"></i>
                 <span>METADATA</span>
               </div>
               <p className="text-slate-400 text-xs italic">Modified via Gemini Flash-Image using instruction: "{prompt}"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;
