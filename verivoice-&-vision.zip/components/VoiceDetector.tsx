
import React, { useState, useRef, useEffect } from 'react';
import { FileData, VoiceDetectionResult, DetectionLanguage } from '../types';
import { detectVoiceGeneration } from '../services/geminiService';

const LANGUAGES: DetectionLanguage[] = ['Auto-detect', 'English', 'Tamil', 'Hindi', 'Malayalam', 'Telugu'];

// Custom Radar Chart Component
const RadarChart: React.FC<{ scores: { label: string; value: number }[]; color: string }> = ({ scores, color }) => {
  const size = 200;
  const center = size / 2;
  const radius = size * 0.4;
  const angleStep = (Math.PI * 2) / scores.length;

  const points = scores.map((s, i) => {
    const x = center + radius * s.value * Math.sin(i * angleStep);
    const y = center - radius * s.value * Math.cos(i * angleStep);
    return `${x},${y}`;
  }).join(' ');

  const axisPoints = scores.map((_, i) => {
    const x = center + radius * Math.sin(i * angleStep);
    const y = center - radius * Math.cos(i * angleStep);
    return { x, y };
  });

  return (
    <div className="relative flex flex-col items-center">
      <svg width={size} height={size} className="overflow-visible drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]">
        {/* Background Hexagons */}
        {[0.2, 0.4, 0.6, 0.8, 1].map((r) => (
          <polygon
            key={r}
            points={scores.map((_, i) => {
              const x = center + radius * r * Math.sin(i * angleStep);
              const y = center - radius * r * Math.cos(i * angleStep);
              return `${x},${y}`;
            }).join(' ')}
            className="fill-none stroke-slate-800 stroke-1"
          />
        ))}
        {/* Axes */}
        {axisPoints.map((p, i) => (
          <line key={i} x1={center} y1={center} x2={p.x} y2={p.y} className="stroke-slate-800 stroke-1" />
        ))}
        {/* Data Shape */}
        <polygon
          points={points}
          className={`${color} fill-opacity-20 stroke-2 transition-all duration-1000 ease-in-out`}
          style={{ stroke: 'currentColor', fill: 'currentColor' }}
        />
        {/* Data Points */}
        {scores.map((s, i) => {
          const x = center + radius * s.value * Math.sin(i * angleStep);
          const y = center - radius * s.value * Math.cos(i * angleStep);
          return <circle key={i} cx={x} cy={y} r="3" className={`${color} fill-current`} />;
        })}
      </svg>
      {/* Labels */}
      <div className="absolute inset-0 pointer-events-none">
        {scores.map((s, i) => {
          const x = 50 + 55 * Math.sin(i * angleStep);
          const y = 50 - 55 * Math.cos(i * angleStep);
          return (
            <div
              key={i}
              className="absolute text-[8px] font-black uppercase tracking-tighter text-slate-500 whitespace-nowrap transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              {s.label}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Circular Gauge Component
const ConfidenceGauge: React.FC<{ value: number; color: string }> = ({ value, color }) => {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value * circumference);

  return (
    <div className="relative flex flex-col items-center justify-center">
      <svg width="100" height="100" className="transform -rotate-90">
        <circle cx="50" cy="50" r={radius} className="fill-none stroke-slate-800 stroke-[6]" />
        <circle
          cx="50"
          cy="50"
          r={radius}
          className={`fill-none stroke-[6] transition-all duration-1000 ease-out ${color}`}
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: offset,
            strokeLinecap: 'round',
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-black font-mono">{(value * 100).toFixed(0)}</span>
        <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">% CERT</span>
      </div>
    </div>
  );
};

const VoiceDetector: React.FC = () => {
  const [file, setFile] = useState<FileData | null>(null);
  const [language, setLanguage] = useState<DetectionLanguage>('Auto-detect');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VoiceDetectionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    if (!selectedFile.type.startsWith('audio/')) {
      setError("Please upload an audio file (MP3/WAV)");
      return;
    }
    processAudioFile(selectedFile);
  };

  const processAudioFile = (audioFile: File | Blob, name: string = 'recorded_audio.wav') => {
    setError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      setFile({
        base64,
        mimeType: audioFile.type || 'audio/wav',
        previewUrl: URL.createObjectURL(audioFile),
        fileName: name
      });
      setResult(null);
    };
    reader.readAsDataURL(audioFile);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => e.data.size > 0 && audioChunksRef.current.push(e.data);
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        processAudioFile(audioBlob, `LiveCapture_${Date.now()}.wav`);
        stream.getTracks().forEach(t => t.stop());
      };
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = window.setInterval(() => setRecordingTime(p => p + 1), 1000);
    } catch (err) {
      setError("Microphone access denied.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) window.clearInterval(timerRef.current);
    }
  };

  const handleDetect = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const detection = await detectVoiceGeneration(file.base64, file.mimeType, language);
      setResult(detection);
    } catch (err: any) {
      setError(err.message || "Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  const radarData = result ? [
    { label: "Prosody", value: result.subScores.prosodyNaturalness },
    { label: "Spectral", value: result.subScores.spectralConsistency },
    { label: "Authenticity", value: 1 - result.subScores.artifactPresence },
    { label: "Emotion", value: result.subScores.emotionalNuance },
    { label: "Cadence", value: (result.subScores.prosodyNaturalness + result.subScores.emotionalNuance) / 2 }
  ] : [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fadeIn">
      {/* Control Panel */}
      <div className="glass-card p-6 md:p-8 rounded-[2.5rem] flex flex-col h-fit border-slate-700/30">
        <div className="flex justify-between items-start mb-10">
          <div>
            <h2 className="text-3xl font-black tracking-tighter flex items-center gap-3">
              <span className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <i className="fas fa-satellite-dish text-white text-base"></i>
              </span>
              CAPTURE
            </h2>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Audio Signal Input Terminal</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <button 
            onClick={() => fileInputRef.current?.click()}
            className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition-all group ${
              file && !isRecording ? 'border-blue-500 bg-blue-500/5' : 'border-slate-800 hover:border-slate-700 hover:bg-slate-800/20'
            }`}
          >
            <input type="file" ref={fileInputRef} className="hidden" accept="audio/*" onChange={handleFileChange} />
            <i className="fas fa-cloud-arrow-up text-3xl mb-3 text-blue-500 group-hover:scale-110 transition-transform"></i>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 group-hover:text-blue-400">Import Log</span>
          </button>

          <button 
            onClick={isRecording ? stopRecording : startRecording}
            className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition-all group relative overflow-hidden ${
              isRecording ? 'border-red-500 bg-red-500/10' : 'border-slate-800 hover:border-slate-700 hover:bg-slate-800/20'
            }`}
          >
            {isRecording && <div className="absolute inset-0 bg-red-500/5 animate-pulse"></div>}
            <i className={`fas ${isRecording ? 'fa-stop-circle text-red-500' : 'fa-microphone-alt text-slate-500'} text-3xl mb-3 group-hover:scale-110 transition-transform`}></i>
            <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${isRecording ? 'text-red-500' : 'text-slate-400'}`}>
              {isRecording ? `${Math.floor(recordingTime/60)}:${(recordingTime%60).toString().padStart(2,'0')}` : 'Live Capture'}
            </span>
          </button>
        </div>

        {file && !isRecording && (
          <div className="mb-8 p-5 bg-slate-950/50 rounded-3xl border border-slate-800/50 shadow-inner">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
                <i className="fas fa-wave-square text-blue-400 text-lg"></i>
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-black text-slate-300 truncate uppercase tracking-tighter">{file.fileName}</p>
                <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Buffer Loaded</p>
              </div>
              <button onClick={() => setFile(null)} className="w-8 h-8 flex items-center justify-center text-slate-600 hover:text-red-500 transition-colors">
                <i className="fas fa-trash-alt text-sm"></i>
              </button>
            </div>
            <audio controls src={file.previewUrl} className="w-full h-10 brightness-75 contrast-125 rounded-lg" />
          </div>
        )}

        <div className="mb-10">
          <label className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-500 mb-5 block">Neural Lexicon Context</label>
          <div className="grid grid-cols-3 gap-2">
            {LANGUAGES.map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-2 py-3 rounded-2xl text-[9px] font-black transition-all border-2 uppercase tracking-widest ${
                  language === lang 
                    ? 'bg-blue-600 border-blue-400 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]' 
                    : 'bg-slate-900 border-slate-800 text-slate-600 hover:border-slate-700'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <button
          disabled={!file || loading || isRecording}
          onClick={handleDetect}
          className={`w-full py-6 rounded-[2rem] font-black text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-4 group ${
            !file || loading || isRecording
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-50' 
              : 'bg-gradient-to-r from-blue-700 to-blue-600 hover:from-blue-600 hover:to-blue-500 text-white shadow-2xl shadow-blue-900/40'
          }`}
        >
          {loading ? (
            <><i className="fas fa-atom fa-spin"></i>Processing DNA...</>
          ) : (
            <><i className="fas fa-fingerprint group-hover:rotate-12 transition-transform"></i>Scan Origin</>
          )}
        </button>

        {error && <div className="mt-6 p-4 bg-red-500/5 border border-red-500/20 rounded-2xl text-red-400 text-[9px] font-bold uppercase tracking-[0.1em] flex items-center gap-3"><i className="fas fa-shield-virus"></i>{error}</div>}
      </div>

      {/* Graphical Result Panel */}
      <div className="flex flex-col gap-6">
        <div className="glass-card p-6 md:p-8 rounded-[2.5rem] min-h-[600px] flex flex-col relative overflow-hidden border-slate-700/30">
          {/* Diagnostic Grid Background */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
               style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />

          <h2 className="text-2xl font-black mb-10 flex items-center gap-3 relative z-10">
            <span className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <i className="fas fa-chart-pie text-white text-base"></i>
            </span>
            DIAGNOSTICS
          </h2>

          {!result && !loading && (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-800 space-y-6">
              <div className="w-48 h-48 border border-slate-800/50 rounded-full flex items-center justify-center relative">
                <div className="absolute inset-0 border border-slate-800/30 rounded-full animate-ping opacity-20"></div>
                <i className="fas fa-radar text-7xl opacity-5"></i>
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] animate-pulse">Awaiting Signal Synchronization</p>
            </div>
          )}

          {loading && (
            <div className="flex-1 flex flex-col items-center justify-center space-y-10 relative z-10">
              <div className="w-32 h-32 relative">
                <svg className="w-full h-full animate-spin-slow">
                  <circle cx="64" cy="64" r="60" className="fill-none stroke-blue-500/10 stroke-[1]" />
                  <circle cx="64" cy="64" r="60" className="fill-none stroke-blue-500 stroke-[2] transition-all" strokeDasharray="10 30" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-12 h-1 bg-blue-500 animate-[width_2s_infinite]"></div>
                </div>
              </div>
              <div className="text-center space-y-2">
                <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.5em] animate-pulse">Spectral Mapping</p>
                <p className="text-slate-600 text-[8px] font-mono tracking-widest">FREQ_ANALYSIS_IN_PROGRESS...</p>
              </div>
            </div>
          )}

          {result && !loading && (
            <div className="space-y-8 animate-fadeIn relative z-10">
              {/* Verdict Section */}
              <div className={`p-8 rounded-[2rem] border-2 relative overflow-hidden group ${
                result.classification === 'Human' ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'
              }`}>
                <div className="absolute -right-8 -bottom-8 opacity-[0.05] group-hover:scale-110 transition-transform">
                  <i className={`fas ${result.classification === 'Human' ? 'fa-id-badge' : 'fa-robot'} text-9xl`}></i>
                </div>
                
                <div className="flex items-start justify-between relative">
                  <div>
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-3 block">Neural Verdict</span>
                    <h3 className={`text-5xl font-black tracking-tighter mb-2 ${
                      result.classification === 'Human' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {result.classification}
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-slate-900 rounded text-[8px] font-black text-slate-400 uppercase tracking-widest border border-slate-800">
                        {result.languageDetected || 'Universal'}
                      </span>
                    </div>
                  </div>
                  <ConfidenceGauge 
                    value={result.confidence} 
                    color={result.classification === 'Human' ? 'text-green-400' : 'text-red-400'} 
                  />
                </div>
              </div>

              {/* Graphic Data Visualization */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Radar Chart Area */}
                <div className="bg-slate-950/40 p-6 rounded-[2rem] border border-slate-800/50 flex flex-col items-center">
                  <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] mb-6 self-start">Spectral Footprint</span>
                  <RadarChart 
                    scores={radarData} 
                    color={result.classification === 'Human' ? 'text-green-500' : 'text-red-500'} 
                  />
                </div>

                {/* Sub-Metric Summary Area */}
                <div className="flex flex-col gap-4">
                  {[
                    { label: 'Prosody Naturalness', val: result.subScores.prosodyNaturalness, icon: 'fa-wind', c: 'text-blue-400' },
                    { label: 'Spectral Consistency', val: result.subScores.spectralConsistency, icon: 'fa-microchip', c: 'text-purple-400' },
                    { label: 'Artifact Minimization', val: 1 - result.subScores.artifactPresence, icon: 'fa-shield-virus', c: 'text-pink-400' },
                    { label: 'Emotional Nuance', val: result.subScores.emotionalNuance, icon: 'fa-heartbeat', c: 'text-emerald-400' }
                  ].map((m, i) => (
                    <div key={i} className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/50 flex items-center justify-between group hover:bg-slate-900/60 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center ${m.c}`}>
                          <i className={`fas ${m.icon} text-xs`}></i>
                        </div>
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{m.label}</span>
                      </div>
                      <span className="text-xs font-mono font-black text-slate-200">{(m.val * 100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Footnote */}
              <div className="p-6 bg-slate-950/40 rounded-[2rem] border border-slate-800/50 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5"><i className="fas fa-terminal text-4xl"></i></div>
                <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] mb-3 block">Forensic Summary</span>
                <p className="text-slate-300 text-sm leading-relaxed font-medium italic">
                  "{result.explanation}"
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                 <button 
                  onClick={() => setResult(null)} 
                  className="flex-1 py-5 bg-slate-900 hover:bg-slate-800 text-slate-500 rounded-3xl text-[10px] font-black uppercase tracking-[0.3em] transition-all border border-slate-800"
                >
                  Reset Protocol
                </button>
                 <button className="px-10 py-5 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 rounded-3xl border border-blue-500/20 transition-all">
                    <i className="fas fa-download text-sm"></i>
                 </button>
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default VoiceDetector;
