
export type DetectionLanguage = 'Tamil' | 'English' | 'Hindi' | 'Malayalam' | 'Telugu' | 'Auto-detect';

export interface VoiceSubScores {
  prosodyNaturalness: number;
  spectralConsistency: number;
  artifactPresence: number;
  emotionalNuance: number;
}

export interface VoiceDetectionResult {
  classification: 'AI' | 'Human';
  confidence: number;
  explanation: string;
  languageDetected?: string;
  subScores: VoiceSubScores;
}

export interface AppState {
  activeTab: 'voice' | 'image';
}

export interface FileData {
  base64: string;
  mimeType: string;
  previewUrl: string;
  fileName: string;
}
